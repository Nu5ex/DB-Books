package pablo.fernandez.dam.mp09.uf03.a01.config;

public class Settings {
	public static final String IP = "127.0.0.1";
	public static final int PORT = 5000;
}
